package com.smsautoprint

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Stores accepted/printed SMS sales separately by company/rule. */
object SmsSaleStore {
    data class Sale(
        val id: Long,
        val company: String,
        val sender: String,
        val transactionId: String,
        val amount: Double,
        val serviceCharge: Double,
        val timestamp: Long
    )

    private const val PREF = "sms_sales"
    private const val KEY = "sales"

    fun add(c: Context, sale: Sale) {
        val list = load(c).toMutableList()
        if (list.any { it.company.equals(sale.company, true) && it.transactionId.equals(sale.transactionId, true) && it.transactionId.isNotBlank() }) return
        list += sale
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().apply {
                put("id", it.id); put("company", it.company); put("sender", it.sender)
                put("trx", it.transactionId); put("amount", it.amount)
                put("charge", it.serviceCharge); put("timestamp", it.timestamp)
            })
        }
        c.getSharedPreferences(PREF, 0).edit().putString(KEY, a.toString()).apply()
    }

    fun load(c: Context): List<Sale> {
        val raw = c.getSharedPreferences(PREF, 0).getString(KEY, null) ?: return emptyList()
        val a = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        return buildList {
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                add(Sale(o.optLong("id"), o.optString("company"), o.optString("sender"),
                    o.optString("trx"), o.optDouble("amount"), o.optDouble("charge"), o.optLong("timestamp")))
            }
        }
    }

    fun companyTotals(c: Context): Map<String, Pair<Int, Double>> =
        load(c).groupBy { it.company.ifBlank { "Default" } }
            .mapValues { (_, rows) -> rows.size to rows.sumOf { it.amount } }

    fun totalSale(c: Context): Double = load(c).sumOf { it.amount }
    fun totalTransactions(c: Context): Int = load(c).size
    fun totalCharges(c: Context): Double = load(c).sumOf { it.serviceCharge }
}
