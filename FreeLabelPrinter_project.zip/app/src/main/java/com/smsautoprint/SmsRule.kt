package com.smsautoprint

data class SmsRule(
    val name: String,
    val senderContains: String = "",
    val requiredKeywords: List<String> = emptyList(),
    val transactionKeywords: List<String> = listOf(
        "transaction id", "transfer id", "trx id", "txn id",
        "transaction", "transfer", "trx", "txn", "reference", "ref", "rrn"
    ),
    val amountKeywords: List<String> = listOf("amount", "rs", "pkr"),
    val enabled: Boolean = true
)