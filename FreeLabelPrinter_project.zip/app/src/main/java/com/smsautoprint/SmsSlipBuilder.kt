package com.smsautoprint

object SmsSlipBuilder {
    fun build(header: String, number: String, trx: String, amount: Double,
             charge: Double, showCharge: Boolean, dateTime: String, footer: String): String =
        buildString {
            if (header.isNotBlank()) append(header).append("\n")
            append("--------------------------------\n")
            if (number.isNotBlank()) append("Number: ").append(number).append("\n")
            if (trx.isNotBlank()) append("TRX ID: ").append(trx).append("\n")
            append("Amount: Rs. ").append(money(amount)).append("\n")
            if (showCharge) append("Service Charges: Rs. ").append(money(charge)).append("\n")
            append("Date: ").append(dateTime.substringBefore(" ")).append("\n")
            append("Time: ").append(dateTime.substringAfter(" ")).append("\n")
            append("--------------------------------\n")
            if (footer.isNotBlank()) append(footer).append("\n")
        }

    private fun money(v: Double) =
        if (v % 1.0 == 0.0) v.toLong().toString() else "%.2f".format(v)
}