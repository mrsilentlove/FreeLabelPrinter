package com.smsautoprint

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object SmsRuleStore {
    private const val KEY = "sms_rules"
    fun save(context: Context, rules: List<SmsRule>) {
        val a = JSONArray()
        rules.forEach { r ->
            a.put(JSONObject().apply {
                put("name", r.name)
                put("sender", r.senderContains)
                put("required", JSONArray(r.requiredKeywords))
                put("trx", JSONArray(r.transactionKeywords))
                put("amount", JSONArray(r.amountKeywords))
                put("enabled", r.enabled)
            })
        }
        context.getSharedPreferences("sms_rules", 0).edit().putString(KEY, a.toString()).apply()
    }

    fun load(context: Context): MutableList<SmsRule> {
        val raw = context.getSharedPreferences("sms_rules", 0).getString(KEY, null) ?: return mutableListOf()
        val a = JSONArray(raw)
        val out = mutableListOf<SmsRule>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            fun arr(k: String): List<String> {
                val x = o.optJSONArray(k) ?: return emptyList()
                return List(x.length()) { n -> x.optString(n) }
            }
            out += SmsRule(
                o.optString("name"),
                o.optString("sender"),
                arr("required"),
                arr("trx"),
                arr("amount"),
                o.optBoolean("enabled", true)
            )
        }
        return out
    }
}