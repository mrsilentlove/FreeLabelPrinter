package com.smsautoprint

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object SmsPrintService {
    suspend fun process(c: Context, sender: String, body: String, receivedAt: Long = System.currentTimeMillis()): Boolean {
        val rule = SmsRuleManager.enabled(c).firstOrNull { r ->
            (r.senderContains.isBlank() || sender.contains(r.senderContains, true)) &&
            r.requiredKeywords.all { body.contains(it, true) }
        } ?: return false

        val parsed = SmsParser.parse(body, rule) ?: return false
        val key = (parsed.transactionId + "|" + parsed.amount + "|" + sender).lowercase()
        val prefs = c.getSharedPreferences("printed_sms", 0)
        if (prefs.getBoolean(key, false)) return false

        val charge = SmsSettings.charge(c)
        val finalAmount = parsed.amount + charge
        val slip = SmsSlipBuilder.build(
            SmsSettings.headerText(c), parsed.number.ifBlank { sender }, parsed.transactionId,
            finalAmount, charge, SmsSettings.showCharge(c),
            SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale.getDefault()).format(Date(receivedAt)),
            SmsSettings.footerText(c)
        )

        val printResult = TspSmsPrintBridge.print(c, slip)
        if (printResult.isFailure) return false

        SmsSaleStore.add(c, SmsSaleStore.Sale(
            id = System.currentTimeMillis(), company = rule.name, sender = sender,
            transactionId = parsed.transactionId, amount = parsed.amount,
            serviceCharge = charge, timestamp = receivedAt
        ))
        prefs.edit().putBoolean(key, true).apply()
        return true
    }
}
