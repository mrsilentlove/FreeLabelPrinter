package com.smsautoprint

import android.content.Context

object SmsRuleManager {
    fun addOrReplace(c:Context, rule:SmsRule) {
        val list=SmsRuleStore.load(c)
        val i=list.indexOfFirst{it.name.equals(rule.name,true)}
        if(i>=0) list[i]=rule else list.add(rule)
        SmsRuleStore.save(c,list)
    }
    fun remove(c:Context,name:String) {
        SmsRuleStore.save(c,SmsRuleStore.load(c).filterNot{it.name.equals(name,true)})
    }
    fun enabled(c:Context)=SmsRuleStore.load(c).filter{it.enabled}
}