package com.smsautoprint

data class ParsedSms(
    val number: String,
    val transactionId: String,
    val amount: Double
)

object SmsParser {
    fun parse(body: String, rule: SmsRule): ParsedSms? {
        val number = Regex("""(?<!\d)(?:0\d{9,10}|\+92\d{10,11})(?!\d)""")
            .find(body)?.value ?: ""

        val lower = body.lowercase()
        val trx = findAfterKeywords(body, lower, rule.transactionKeywords)
        val amount = findAmount(body, lower, rule.amountKeywords) ?: return null

        if (trx.isBlank() && rule.transactionKeywords.isNotEmpty()) return null
        return ParsedSms(number, trx, amount)
    }

    private fun findAfterKeywords(body: String, lower: String, keys: List<String>): String {
        for (key in keys.sortedByDescending { it.length }) {
            val i = lower.indexOf(key.lowercase())
            if (i < 0) continue
            val tail = body.substring((i + key.length).coerceAtMost(body.length))
            val m = Regex("""[:#=\-\s]*([A-Za-z0-9][A-Za-z0-9._/\-]{3,})""").find(tail)
            if (m != null) return m.groupValues[1]
        }
        return ""
    }

    private fun findAmount(body: String, lower: String, keys: List<String>): Double? {
        for (key in keys.sortedByDescending { it.length }) {
            val i = lower.indexOf(key.lowercase())
            if (i >= 0) {
                val tail = body.substring((i + key.length).coerceAtMost(body.length))
                val m = Regex("""\s*[:=\-]?\s*([0-9][0-9,]*(?:\.[0-9]+)?)""").find(tail)
                if (m != null) return m.groupValues[1].replace(",", "").toDoubleOrNull()
            }
        }
        Regex("""(?i)(?:rs\.?|pkr)\s*([0-9][0-9,]*(?:\.[0-9]+)?)""").find(body)?.let {
            return it.groupValues[1].replace(",", "").toDoubleOrNull()
        }
        return null
    }
}