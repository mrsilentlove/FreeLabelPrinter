package com.smsautoprint

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import com.example.freelabelprinter.printer.StarPrinterManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object TspSmsPrintBridge {
    suspend fun print(context: Context, text: String): Result<Unit> = withContext(Dispatchers.IO) {
        val manager = StarPrinterManager(context.applicationContext)
        val printer = try {
            suspendCancellableCoroutine { cont ->
                manager.discover(
                    onFound = { p ->
                        manager.select(p)
                        if (cont.isActive) cont.resume(Unit)
                    },
                    onFinished = {
                        if (manager.identifier() == null && cont.isActive) {
                            cont.resumeWithException(IllegalStateException("No Star Bluetooth printer found"))
                        }
                    },
                    onError = { t ->
                        if (cont.isActive) cont.resumeWithException(t)
                    }
                )
                cont.invokeOnCancellation { manager.stopDiscovery() }
            }
            manager
        } catch (t: Throwable) {
            manager.stopDiscovery()
            return@withContext Result.failure(t)
        }

        printer.stopDiscovery()
        val bitmap = textToBitmap(text)
        manager.printBitmap(bitmap)
    }

    private fun textToBitmap(text: String): Bitmap {
        val width = 576
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.BLACK
            textSize = 28f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
        }
        val lines = text.lines().flatMap { line ->
            if (line.length <= 34) listOf(line) else line.chunked(34)
        }
        val lineHeight = 36
        val height = (lines.size.coerceAtLeast(1) * lineHeight) + 24
        return Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).also { bitmap ->
            Canvas(bitmap).apply {
                drawColor(android.graphics.Color.WHITE)
                lines.forEachIndexed { index, line ->
                    drawText(line, 12f, 30f + index * lineHeight, paint)
                }
            }
        }
    }
}
