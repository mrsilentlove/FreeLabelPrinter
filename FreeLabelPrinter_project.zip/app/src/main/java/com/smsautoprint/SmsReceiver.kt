package com.smsautoprint

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        val pending = goAsync()
        val job: Job = CoroutineScope(Dispatchers.IO).launch {
            try {
                for (sms in Telephony.Sms.Intents.getMessagesFromIntent(intent)) {
                    SmsPrintService.process(
                        context.applicationContext,
                        sms.originatingAddress.orEmpty(),
                        sms.messageBody.orEmpty(),
                        sms.timestampMillis
                    )
                }
            } finally {
                pending.finish()
            }
        }
        pending.setResultCode(android.app.Activity.RESULT_OK)
    }
}
