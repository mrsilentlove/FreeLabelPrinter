package com.smsautoprint

import android.content.Context

object SmsSettings {
    private const val P = "sms_print"
    private fun p(c: Context)=c.getSharedPreferences(P,0)

    fun setHeaderText(c:Context,v:String)=p(c).edit().putString("header_text",v).apply()
    fun setFooterText(c:Context,v:String)=p(c).edit().putString("footer_text",v).apply()
    fun setCharge(c:Context,v:Double)=p(c).edit().putString("service_charge",v.toString()).apply()
    fun setShowCharge(c:Context,v:Boolean)=p(c).edit().putBoolean("show_charge",v).apply()
    fun setHeaderImage(c:Context,uri:String)=p(c).edit().putString("header_image",uri).apply()
    fun setFooterImage(c:Context,uri:String)=p(c).edit().putString("footer_image",uri).apply()

    fun headerText(c:Context)=p(c).getString("header_text","")?:""
    fun footerText(c:Context)=p(c).getString("footer_text","")?:""
    fun charge(c:Context)=p(c).getString("service_charge","0")?.toDoubleOrNull()?:0.0
    fun showCharge(c:Context)=p(c).getBoolean("show_charge",false)
    fun headerImage(c:Context)=p(c).getString("header_image",null)
    fun footerImage(c:Context)=p(c).getString("footer_image",null)
}