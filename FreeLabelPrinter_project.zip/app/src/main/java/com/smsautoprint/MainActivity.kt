package com.smsautoprint

import android.Manifest
import android.app.Activity
import android.os.Bundle
import android.content.pm.PackageManager
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class SmsSettingsActivity:Activity(){
 override fun onCreate(b:Bundle?){
  super.onCreate(b); setContentView(R.layout.activity_main)
  if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECEIVE_SMS)!=PackageManager.PERMISSION_GRANTED)
   ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.RECEIVE_SMS,Manifest.permission.READ_SMS),50)

  val shop=findViewById<EditText>(R.id.shop); val sender=findViewById<EditText>(R.id.sender)
  val keywords=findViewById<EditText>(R.id.keywords); val trx=findViewById<EditText>(R.id.trx)
  val amount=findViewById<EditText>(R.id.amountKeywords); val charge=findViewById<EditText>(R.id.charge)
  val header=findViewById<EditText>(R.id.header); val footer=findViewById<EditText>(R.id.footer)
  val show=findViewById<Switch>(R.id.showCharge); val save=findViewById<Button>(R.id.save); val sales=findViewById<Button>(R.id.sales)

  shop.setText(SmsSettings.headerText(this)); header.setText(SmsSettings.headerText(this))
  footer.setText(SmsSettings.footerText(this)); charge.setText(SmsSettings.charge(this).toString())
  show.isChecked=SmsSettings.showCharge(this)

  sales.setOnClickListener{
   val totals=SmsSaleStore.companyTotals(this)
   val text=buildString {
    append("SMS SALES TOTALS\n\n")
    append("All Companies: Rs. ").append(SmsSaleStore.totalSale(this@SmsSettingsActivity)).append("\n")
    append("Transactions: ").append(SmsSaleStore.totalTransactions(this@SmsSettingsActivity)).append("\n")
    append("Service Charges: Rs. ").append(SmsSaleStore.totalCharges(this@SmsSettingsActivity)).append("\n\n")
    if(totals.isEmpty()) append("No SMS sales yet.")
    else totals.forEach { (company, pair) -> append(company).append(": ").append(pair.first).append(" txns — Rs. ").append(pair.second).append("\n") }
   }
   android.app.AlertDialog.Builder(this).setTitle("SMS Sales / Company Totals").setMessage(text).setPositiveButton("OK",null).show()
  }

  save.setOnClickListener{
   SmsSettings.setHeaderText(this,header.text.toString()); SmsSettings.setFooterText(this,footer.text.toString())
   SmsSettings.setCharge(this,charge.text.toString().toDoubleOrNull()?:0.0); SmsSettings.setShowCharge(this,show.isChecked)
   val rule=SmsRule(
    name=shop.text.toString().ifBlank{"Default"},
    senderContains=sender.text.toString(),
    requiredKeywords=keywords.text.toString().split(",").map{it.trim()}.filter{it.isNotBlank()},
    transactionKeywords=trx.text.toString().split(",").map{it.trim()}.filter{it.isNotBlank()}.ifEmpty{SmsRule("x").transactionKeywords},
    amountKeywords=amount.text.toString().split(",").map{it.trim()}.filter{it.isNotBlank()}.ifEmpty{SmsRule("x").amountKeywords},
    enabled=true
   )
   SmsRuleManager.addOrReplace(this,rule)
   Toast.makeText(this,"Rule saved",Toast.LENGTH_SHORT).show()
  }
 }
}