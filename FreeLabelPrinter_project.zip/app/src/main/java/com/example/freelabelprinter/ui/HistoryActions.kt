package com.example.freelabelprinter.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.freelabelprinter.data.LocalStore
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HistoryActionsScreen(context: Context, onReprint: (String) -> Unit = {}) {
    val store = remember { LocalStore(context) }
    var refresh by remember { mutableIntStateOf(0) }
    val records = remember(refresh) { store.history() }

    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Text("Print History", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(records) { r ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(r.title.ifBlank { r.type }, style = MaterialTheme.typography.titleMedium)
                        Text("${r.type} • ${SimpleDateFormat("dd-MM-yyyy hh:mm a", Locale.getDefault()).format(Date(r.timestamp))}")
                        Text("Copies: ${r.copies}")

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { onReprint(r.dataJson) }) {
                                Text("Reprint")
                            }
                            OutlinedButton(onClick = {
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, r.dataJson)
                                }
                                context.startActivity(Intent.createChooser(send, "Share print data"))
                            }) {
                                Text("Share")
                            }
                        }
                    }
                }
            }
        }
    }
}
