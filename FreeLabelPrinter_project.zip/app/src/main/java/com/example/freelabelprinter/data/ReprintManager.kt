package com.example.freelabelprinter.data

import android.graphics.Bitmap

class ReprintManager(private val store: LocalStore) {
    fun recordReceipt(title: String, printer: String, dataJson: String) {
        store.addPrintRecord(
            PrintRecord(
                type = "RECEIPT",
                title = title,
                printer = printer,
                dataJson = dataJson
            )
        )
    }

    fun recordLabel(title: String, printer: String, dataJson: String) {
        store.addPrintRecord(
            PrintRecord(
                type = "LABEL",
                title = title,
                printer = printer,
                dataJson = dataJson
            )
        )
    }
}
