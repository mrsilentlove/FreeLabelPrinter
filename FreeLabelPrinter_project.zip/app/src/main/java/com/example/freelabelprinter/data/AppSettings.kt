package com.example.freelabelprinter.data

data class AppSettings(
    val paperWidthMm: Double = 80.0,
    val autoCut: Boolean = true,
    val printCopies: Int = 1,
    val defaultReceiptTemplate: String = "Default Receipt",
    val defaultLabelWidthMm: Double = 25.0,
    val defaultLabelHeightMm: Double = 20.0,
    val defaultGapMm: Double = 2.0
)
