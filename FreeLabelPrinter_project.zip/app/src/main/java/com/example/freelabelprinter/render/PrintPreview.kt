package com.example.freelabelprinter.render

import android.graphics.Bitmap

data class PrintPreview(
    val bitmap: Bitmap,
    val columns: Int,
    val rows: Int,
    val paperWidthMm: Double
)

fun makePreview(
    paperWidthMm: Double,
    labelWidthMm: Double,
    labelHeightMm: Double,
    gapMm: Double,
    items: List<LabelContent>
): PrintPreview {
    val layout = LabelLayout(
        paperWidthMm = paperWidthMm,
        labelWidthMm = labelWidthMm,
        labelHeightMm = labelHeightMm,
        gapMm = gapMm
    )
    return PrintPreview(
        bitmap = LabelBitmapRenderer().render(layout, items),
        columns = layout.columns(),
        rows = maxOf(1, (items.size + layout.columns() - 1) / layout.columns()),
        paperWidthMm = paperWidthMm
    )
}
