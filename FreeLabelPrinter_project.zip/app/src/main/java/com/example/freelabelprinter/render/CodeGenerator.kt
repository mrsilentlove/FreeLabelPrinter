package com.example.freelabelprinter.render

import android.graphics.Bitmap
import android.graphics.Color
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import com.google.zxing.common.BitMatrix

object CodeGenerator {
    fun qr(text: String, size: Int = 320): Bitmap =
        make(text, BarcodeFormat.QR_CODE, size, size)

    fun code128(text: String, width: Int = 500, height: Int = 150): Bitmap =
        make(text, BarcodeFormat.CODE_128, width, height)

    private fun make(text: String, format: BarcodeFormat, width: Int, height: Int): Bitmap {
        require(text.isNotBlank()) { "Barcode/QR value is empty" }
        val hints = mapOf(
            EncodeHintType.MARGIN to 1,
            EncodeHintType.CHARACTER_SET to "UTF-8"
        )
        val matrix: BitMatrix = MultiFormatWriter().encode(text, format, width, height, hints)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        for (x in 0 until width) {
            for (y in 0 until height) {
                bitmap.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
            }
        }
        return bitmap
    }
}
