package com.example.freelabelprinter.data

import android.content.Context
import org.json.JSONArray

class TemplateStore(context: Context) {
    private val prefs = context.getSharedPreferences("printer_templates", Context.MODE_PRIVATE)

    fun save(t: SavedTemplate) {
        val key = if (t.type == "RECEIPT") "receipts" else "labels"
        val a = JSONArray(prefs.getString(key, "[]"))
        a.put(org.json.JSONObject()
            .put("id", t.id)
            .put("name", t.name)
            .put("type", t.type)
            .put("updatedAt", t.updatedAt)
            .put("dataJson", t.dataJson))
        prefs.edit().putString(key, a.toString()).apply()
    }

    fun delete(type: String, id: Long) {
        val key = if (type == "RECEIPT") "receipts" else "labels"
        val a = JSONArray(prefs.getString(key, "[]"))
        val out = JSONArray()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optLong("id") != id) out.put(o)
        }
        prefs.edit().putString(key, out.toString()).apply()
    }
}
