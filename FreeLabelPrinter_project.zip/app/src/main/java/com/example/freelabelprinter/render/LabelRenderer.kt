package com.example.freelabelprinter.render

import android.graphics.*
import kotlin.math.roundToInt
import kotlin.math.floor

data class LabelLayout(
    val paperWidthMm: Double = 80.0,
    val labelWidthMm: Double = 25.0,
    val labelHeightMm: Double = 20.0,
    val gapMm: Double = 2.0,
    val marginLeftMm: Double = 1.0,
    val marginRightMm: Double = 1.0,
    val topMm: Double = 1.0
) {
    val dpi: Int = 203

    private fun mmToDots(mm: Double): Int =
        (mm * dpi / 25.4).roundToInt()

    fun columns(): Int {
        val usable = paperWidthMm - marginLeftMm - marginRightMm
        return maxOf(1, floor((usable + gapMm) / (labelWidthMm + gapMm)).toInt())
    }

    fun paperWidthDots(): Int = mmToDots(paperWidthMm)

    fun labelWidthDots(): Int = mmToDots(labelWidthMm)

    fun labelHeightDots(): Int = mmToDots(labelHeightMm)

    fun gapDots(): Int = mmToDots(gapMm)
}

data class LabelContent(
    val product: String,
    val price: String,
    val barcode: String? = null
)

class LabelBitmapRenderer {

    fun render(
        layout: LabelLayout,
        items: List<LabelContent>
    ): Bitmap {
        val columns = layout.columns()
        val rows = maxOf(1, (items.size + columns - 1) / columns)

        // Extra bottom space is intentionally small to reduce receipt-roll waste.
        val heightDots =
            layout.mmToDotsForInternal(layout.topMm) +
            rows * layout.labelHeightDots() +
            maxOf(0, rows - 1) * layout.gapDots() +
            layout.mmToDotsForInternal(1.0)

        val bmp = Bitmap.createBitmap(
            layout.paperWidthDots(),
            heightDots,
            Bitmap.Config.ARGB_8888
        )

        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }

        val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        items.forEachIndexed { index, item ->
            val col = index % columns
            val row = index / columns

            val x = layout.mmToDotsForInternal(layout.marginLeftMm) +
                    col * (layout.labelWidthDots() + layout.gapDots())
            val y = layout.mmToDotsForInternal(layout.topMm) +
                    row * (layout.labelHeightDots() + layout.gapDots())

            val left = x.toFloat()
            val top = y.toFloat()
            val right = (x + layout.labelWidthDots()).toFloat()
            val bottom = (y + layout.labelHeightDots()).toFloat()

            canvas.drawRect(left, top, right, bottom, paintStroke())

            val pad = maxOf(3, layout.labelWidthDots() / 30)
            bold.textSize = maxOf(12f, layout.labelHeightDots() * .17f)
            paint.textSize = maxOf(10f, layout.labelHeightDots() * .13f)

            canvas.drawText(
                fit(item.product, bold, right-left-2*pad),
                left + pad,
                top + pad + bold.textSize,
                bold
            )

            canvas.drawText(
                item.price,
                left + pad,
                top + pad + bold.textSize + paint.textSize + 2,
                paint
            )

            // Barcode placeholder area. Real barcode rendering will replace this
            // with a Code128/UPC renderer in the next module.
            if (!item.barcode.isNullOrBlank()) {
                val barTop = bottom - layout.labelHeightDots() * .32f
                val barBottom = bottom - pad
                drawPseudoBarcode(canvas, item.barcode, left + pad, barTop,
                    right - pad, barBottom)
            }
        }

        return bmp
    }

    private fun paintStroke() = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }

    private fun fit(text: String, paint: Paint, maxWidth: Float): String {
        if (paint.measureText(text) <= maxWidth) return text
        var s = text
        while (s.isNotEmpty() && paint.measureText("$s…") > maxWidth) {
            s = s.dropLast(1)
        }
        return "$s…"
    }

    private fun drawPseudoBarcode(
        c: Canvas, value: String, left: Float, top: Float,
        right: Float, bottom: Float
    ) {
        val p = Paint()
        p.color = Color.BLACK
        p.style = Paint.Style.FILL
        var x = left
        val width = maxOf(1f, (right-left) / (value.length * 8f + 20f))
        value.forEachIndexed { i, ch ->
            val bits = (ch.code xor (i * 31)) and 0xFF
            for (b in 0 until 8) {
                if (((bits shr b) and 1) == 1) {
                    c.drawRect(x, top, x + width, bottom, p)
                }
                x += width
            }
            x += width
        }
    }
}

// Kept here so the layout class stays a single source of truth for mm -> dots.
private fun LabelLayout.mmToDotsForInternal(mm: Double): Int =
    (mm * dpi / 25.4).roundToInt()
