package com.example.freelabelprinter.data

data class ReceiptDesign(
    val name: String = "Default Receipt",
    val paperWidthMm: Double = 80.0,
    val shopName: String = "Punjab Restaurant Pizza & Fast Food",
    val phone: String = "",
    val address: String = "",
    val showLogo: Boolean = false,
    val showDateTime: Boolean = true,
    val showReceiptNo: Boolean = true,
    val showItemTable: Boolean = true,
    val showDiscount: Boolean = true,
    val showTax: Boolean = false,
    val showQr: Boolean = false,
    val showBarcode: Boolean = false,
    val footer: String = "Fresh food, happy moods. See you again!",
    val shopNameSize: Int = 24,
    val bodySize: Int = 16,
    val footerSize: Int = 14
)
