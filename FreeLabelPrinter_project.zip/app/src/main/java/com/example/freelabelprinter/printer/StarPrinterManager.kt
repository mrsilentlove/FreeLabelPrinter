package com.example.freelabelprinter.printer

import android.content.Context
import android.graphics.Bitmap
import com.starmicronics.stario10.InterfaceType
import com.starmicronics.stario10.StarDeviceDiscoveryManager
import com.starmicronics.stario10.StarDeviceDiscoveryManagerFactory
import com.starmicronics.stario10.StarPrinter
import com.starmicronics.stario10.starxpandcommand.CutType
import com.starmicronics.stario10.starxpandcommand.DocumentBuilder
import com.starmicronics.stario10.starxpandcommand.ImageParameter
import com.starmicronics.stario10.starxpandcommand.StarXpandCommandBuilder
import com.starmicronics.stario10.starxpandcommand.PrinterBuilder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class StarPrinterManager(private val context: Context) {
    private var discovery: StarDeviceDiscoveryManager? = null
    private var selectedPrinter: StarPrinter? = null

    fun discover(
        onFound: (StarPrinter) -> Unit,
        onFinished: () -> Unit,
        onError: (Throwable) -> Unit
    ) {
        try {
            discovery?.stopDiscovery()
            discovery = StarDeviceDiscoveryManagerFactory.create(
                listOf(InterfaceType.Bluetooth),
                context.applicationContext
            )
            discovery?.discoveryTime = 10_000
            discovery?.callback = object : StarDeviceDiscoveryManager.Callback {
                override fun onPrinterFound(printer: StarPrinter) {
                    // Prefer the first Star Bluetooth printer found.
                    if (selectedPrinter == null) {
                        selectedPrinter = printer
                        onFound(printer)
                    }
                }

                override fun onDiscoveryFinished() {
                    onFinished()
                }
            }
            discovery?.startDiscovery()
        } catch (t: Throwable) {
            onError(t)
        }
    }

    fun select(printer: StarPrinter) {
        selectedPrinter = printer
    }

    fun stopDiscovery() {
        discovery?.stopDiscovery()
    }

    fun identifier(): String? =
        selectedPrinter?.connectionSettings?.identifier

    suspend fun printBitmap(bitmap: Bitmap): Result<Unit> =
        withContext(Dispatchers.IO) {
            val printer = selectedPrinter
                ?: return@withContext Result.failure(
                    IllegalStateException("Printer not selected. Tap Connect first.")
                )

            try {
                val commands = StarXpandCommandBuilder()
                    .addDocument(
                        DocumentBuilder()
                            .addPrinter(
                                PrinterBuilder()
                                    // TSP100III is graphics-only.
                                    .actionPrintImage(ImageParameter(bitmap, 576))
                                    .actionCut(CutType.Partial)
                            )
                    )
                    .getCommands()

                printer.openAsync().await()
                try {
                    printer.printAsync(commands).await()
                } finally {
                    printer.closeAsync().await()
                }

                Result.success(Unit)
            } catch (t: Throwable) {
                Result.failure(t)
            }
        }
}
