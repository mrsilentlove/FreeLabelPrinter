package com.example.freelabelprinter.render

import android.graphics.*
import kotlin.math.roundToInt

data class RenderLabel(
    val widthMm: Double,
    val heightMm: Double,
    val gapMm: Double,
    val paperWidthMm: Double,
    val product: String,
    val price: String,
    val barcode: String
)

object ReceiptLabelRenderer {
    private const val DPI = 203.0
    private const val MM_PER_INCH = 25.4

    private fun mmToDots(mm: Double): Int =
        (mm * DPI / MM_PER_INCH).roundToInt().coerceAtLeast(1)

    /**
     * Renders the complete 80mm receipt/label row to one monochrome-friendly bitmap.
     * TSP100III receives this bitmap as one graphics print operation.
     */
    fun render(label: RenderLabel): Bitmap {
        val paperW = mmToDots(label.paperWidthMm)
        val labelW = mmToDots(label.widthMm)
        val labelH = mmToDots(label.heightMm)
        val gap = mmToDots(label.gapMm)

        val columns = ((paperW + gap) / (labelW + gap))
            .toInt().coerceAtLeast(1)

        val usedW = columns * labelW + (columns - 1) * gap
        val left = ((paperW - usedW) / 2).coerceAtLeast(0)

        val bmp = Bitmap.createBitmap(
            paperW,
            labelH,
            Bitmap.Config.ARGB_8888
        )

        val canvas = Canvas(bmp)
        canvas.drawColor(Color.WHITE)

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }

        val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }

        for (i in 0 until columns) {
            val x = left + i * (labelW + gap)
            val l = x.toFloat()
            val r = (x + labelW).toFloat()

            canvas.drawRect(l + 1, 1, r - 1, labelH - 1f, borderPaint)

            textPaint.textSize = (labelH * .18f).coerceAtLeast(12f)
            canvas.drawText(
                label.product.take(22),
                (l + r) / 2f,
                labelH * .27f,
                textPaint
            )

            textPaint.textSize = (labelH * .23f).coerceAtLeast(14f)
            canvas.drawText(
                label.price.take(14),
                (l + r) / 2f,
                labelH * .53f,
                textPaint
            )

            // Placeholder barcode area. The barcode generator will replace
            // this with a real Code128/UPC/EAN bitmap in the next module.
            val barTop = labelH * .62f
            val barBottom = labelH * .88f
            val barWidth = (labelW * .70f).coerceAtLeast(20f)
            val start = (l + r - barWidth) / 2f
            val bars = 42
            val bw = barWidth / bars
            for (b in 0 until bars) {
                if (b % 2 == 0 || (label.barcode.hashCode() + b) % 5 == 0) {
                    canvas.drawRect(
                        start + b * bw,
                        barTop,
                        start + (b + 1) * bw,
                        barBottom,
                        Paint().apply { color = Color.BLACK }
                    )
                }
            }

            textPaint.textSize = (labelH * .10f).coerceAtLeast(8f)
            canvas.drawText(
                label.barcode.take(18),
                (l + r) / 2f,
                labelH * .98f,
                textPaint
            )
        }

        return bmp
    }
}
