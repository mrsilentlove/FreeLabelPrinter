package com.example.freelabelprinter.data

data class SavedTemplate(
    val id: Long = System.currentTimeMillis(),
    val name: String,
    val type: String,
    val updatedAt: Long = System.currentTimeMillis(),
    val dataJson: String
)
