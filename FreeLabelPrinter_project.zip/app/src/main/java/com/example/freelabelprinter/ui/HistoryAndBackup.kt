package com.example.freelabelprinter.ui

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.freelabelprinter.data.LocalStore
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HistoryScreen(context: Context) {
    val store = remember { LocalStore(context) }
    var refresh by remember { mutableIntStateOf(0) }
    val records = remember(refresh) { store.history() }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Print History", style = MaterialTheme.typography.titleLarge)
        Text("${records.size} saved print records")
        Spacer(Modifier.height(8.dp))
        if (records.isEmpty()) Text("No print history yet.")
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(records) { r ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(r.title.ifBlank { r.type }, style = MaterialTheme.typography.titleMedium)
                        Text("Type: ${r.type}   Copies: ${r.copies}")
                        Text(SimpleDateFormat("dd-MM-yyyy hh:mm:ss a", Locale.getDefault()).format(Date(r.timestamp)))
                        if (r.printer.isNotBlank()) Text("Printer: ${r.printer}")
                    }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = { refresh++ }, modifier = Modifier.fillMaxWidth()) { Text("Refresh") }
    }
}

@Composable
fun BackupScreen(context: Context) {
    val store = remember { LocalStore(context) }
    var message by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Backup & Restore", style = MaterialTheme.typography.titleLarge)
        Text("Templates and print history are packaged into a JSON backup ready for Google Drive integration.")

        Button(onClick = {
            val json = store.exportBackupJson()
            context.getSharedPreferences("printer_app_data", Context.MODE_PRIVATE)
                .edit().putString("last_backup_json", json).apply()
            message = "Backup package created."
        }, modifier = Modifier.fillMaxWidth()) { Text("CREATE BACKUP") }

        OutlinedButton(onClick = {
            val json = context.getSharedPreferences("printer_app_data", Context.MODE_PRIVATE)
                .getString("last_backup_json", null)
            if (json == null) message = "No backup found."
            else { store.restoreBackupJson(json); message = "Backup restored." }
        }, modifier = Modifier.fillMaxWidth()) { Text("RESTORE LAST BACKUP") }

        Text(message)
    }
}
