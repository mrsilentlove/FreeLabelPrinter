package com.example.freelabelprinter

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.content.Intent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.freelabelprinter.data.ReceiptDesign
import com.example.freelabelprinter.printer.StarPrinterManager
import com.example.freelabelprinter.receipt.ReceiptRenderer
import com.example.freelabelprinter.render.LabelBitmapRenderer
import com.example.freelabelprinter.render.LabelContent
import com.example.freelabelprinter.render.LabelLayout
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private lateinit var printerManager: StarPrinterManager
    private val bluetoothPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        printerManager = StarPrinterManager(this)
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            val needed = arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
                .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }.toTypedArray()
            if (needed.isNotEmpty()) bluetoothPermissionLauncher.launch(needed)
        }
        setContent { App(printerManager) }
    }
    override fun onDestroy() { printerManager.stopDiscovery(); super.onDestroy() }
}

@Composable private fun App(manager: StarPrinterManager) {
    var tab by remember { mutableIntStateOf(0) }
    MaterialTheme { Scaffold(topBar = { TopAppBar(title = { Text(if (tab == 0) "Receipt Designer" else "Free Label Printer") }) }) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            Button(onClick = { startActivity(Intent(this@MainActivity, com.smsautoprint.SmsSettingsActivity::class.java)) }, modifier = Modifier.fillMaxWidth()) { Text("SMS Auto Print Settings") }
            TabRow(selectedTabIndex = tab) { Tab(tab == 0, { tab = 0 }, text = { Text("Receipt") }); Tab(tab == 1, { tab = 1 }, text = { Text("Labels") }) }
            if (tab == 0) ReceiptDesigner(manager) else LabelDesigner(manager)
        }
    }}
}

@Composable private fun ReceiptDesigner(manager: StarPrinterManager) {
    val scope = rememberCoroutineScope(); val scroll = rememberScrollState()
    var status by remember { mutableStateOf("Printer not connected") }; var printing by remember { mutableStateOf(false) }; var saved by remember { mutableStateOf(false) }
    var designName by remember { mutableStateOf("My Receipt") }; var shopName by remember { mutableStateOf("Punjab Restaurant Pizza & Fast Food") }
    var phone by remember { mutableStateOf("") }; var address by remember { mutableStateOf("") }; var footer by remember { mutableStateOf("Fresh food, happy moods. See you again!") }
    var shopSize by remember { mutableStateOf("24") }; var bodySize by remember { mutableStateOf("16") }; var footerSize by remember { mutableStateOf("14") }
    var showLogo by remember { mutableStateOf(false) }; var showDate by remember { mutableStateOf(true) }; var showNo by remember { mutableStateOf(true) }
    var showItems by remember { mutableStateOf(true) }; var showDiscount by remember { mutableStateOf(true) }; var showTax by remember { mutableStateOf(false) }; var showQr by remember { mutableStateOf(false) }; var showBarcode by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().verticalScroll(scroll).padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("Design & Layout", style = MaterialTheme.typography.titleLarge)
        Field("Design name", designName) { designName = it }; Field("Shop / Business name", shopName) { shopName = it }; Field("Phone", phone) { phone = it }; Field("Address", address) { address = it }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { NumberField("Shop", shopSize, { shopSize = it }, Modifier.weight(1f)); NumberField("Body", bodySize, { bodySize = it }, Modifier.weight(1f)); NumberField("Footer", footerSize, { footerSize = it }, Modifier.weight(1f)) }
        Text("Receipt Elements", style = MaterialTheme.typography.titleMedium)
        SwitchRow("Logo / image", showLogo) { showLogo = it }; SwitchRow("Date & time", showDate) { showDate = it }; SwitchRow("Receipt number", showNo) { showNo = it }; SwitchRow("Items / Qty / Price / Total", showItems) { showItems = it }; SwitchRow("Discount", showDiscount) { showDiscount = it }; SwitchRow("Tax", showTax) { showTax = it }; SwitchRow("QR code", showQr) { showQr = it }; SwitchRow("Barcode", showBarcode) { showBarcode = it }
        Field("Footer", footer, minLines = 2) { footer = it }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) { Text("Live preview", style = MaterialTheme.typography.titleMedium); Text(shopName, style = MaterialTheme.typography.titleLarge); if (phone.isNotBlank()) Text(phone); if (address.isNotBlank()) Text(address); HorizontalDivider(); if (showDate) Text("Date: 28-09-2026  03:00 PM"); if (showNo) Text("Receipt No: 000001"); if (showItems) { Text("Item                         Qty    Price"); Text("Sample Product              1      Rs 300") }; if (showDiscount) Text("Discount: Rs 0"); if (showTax) Text("Tax: Rs 0"); Text("TOTAL: Rs 300", style = MaterialTheme.typography.titleMedium); if (showQr) Text("[ QR CODE AREA ]"); if (showBarcode) Text("[ BARCODE AREA ]"); Text(footer) } }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { saved = true }, Modifier.weight(1f)) { Text(if (saved) "Saved ✓" else "Save Design") }
            OutlinedButton(onClick = { manager.discover(onFound = { manager.select(it); status = "Connected: ${it.connectionSettings.identifier}" }, onFinished = { if (manager.identifier() == null) status = "No Star Bluetooth printer found" }, onError = { status = "Bluetooth error: ${it.message}" }) }, Modifier.weight(1f)) { Text("Connect") }
        }
        Button(enabled = !printing, onClick = {
            printing = true; status = "Sending receipt to TSP100III..."
            val d = ReceiptDesign(designName, 80.0, shopName, phone, address, showLogo, showDate, showNo, showItems, showDiscount, showTax, showQr, showBarcode, footer, shopSize.toIntOrNull() ?: 24, bodySize.toIntOrNull() ?: 16, footerSize.toIntOrNull() ?: 14)
            val bitmap = ReceiptRenderer().renderDesign(d)
            scope.launch { val result = manager.printBitmap(bitmap); printing = false; status = result.fold({ "Receipt printed ✓" }, { "Print failed: ${it.message ?: it.javaClass.simpleName}" }) }
        }, Modifier.fillMaxWidth()) { Text(if (printing) "Printing..." else "PRINT RECEIPT") }
        Text(status, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable private fun LabelDesigner(manager: StarPrinterManager) {
    val scope = rememberCoroutineScope(); var status by remember { mutableStateOf("Printer not connected") }; var printing by remember { mutableStateOf(false) }
    var width by remember { mutableStateOf("25") }; var height by remember { mutableStateOf("20") }; var gap by remember { mutableStateOf("2") }; var product by remember { mutableStateOf("Product Name") }; var price by remember { mutableStateOf("Rs 0") }; var barcode by remember { mutableStateOf("123456789012") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("Free-size labels on normal 80mm receipt paper."); Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { NumberField("Width mm", width, { width = it }, Modifier.weight(1f)); NumberField("Height mm", height, { height = it }, Modifier.weight(1f)) }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { NumberField("Gap mm", gap, { gap = it }, Modifier.weight(1f)); OutlinedTextField("80", {}, readOnly = true, label = { Text("Paper mm") }, modifier = Modifier.weight(1f)) }
        Field("Product", product) { product = it }; Field("Price", price) { price = it }; Field("Barcode", barcode) { barcode = it }
        val layout = LabelLayout(80.0, width.toDoubleOrNull() ?: 25.0, height.toDoubleOrNull() ?: 20.0, gap.toDoubleOrNull() ?: 2.0); Text("Auto fit: ${layout.columns()} labels / row")
        Button(enabled = !printing, onClick = { printing = true; status = "Sending labels to TSP100III..."; val bitmap = LabelBitmapRenderer().render(layout, listOf(LabelContent(product, price, barcode))); scope.launch { val r = manager.printBitmap(bitmap); printing = false; status = r.fold({ "Labels printed ✓" }, { "Print failed: ${it.message ?: it.javaClass.simpleName}" }) } }, Modifier.fillMaxWidth()) { Text(if (printing) "Printing..." else "PRINT LABELS") }
        Text(status, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable private fun Field(label: String, value: String, minLines: Int = 1, onChange: (String) -> Unit) { OutlinedTextField(value, onChange, label = { Text(label) }, minLines = minLines, modifier = Modifier.fillMaxWidth()) }
@Composable private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label); Switch(checked, onChange) } }
@Composable private fun NumberField(label: String, value: String, onChange: (String) -> Unit, modifier: Modifier) { OutlinedTextField(value, { if (it.all(Char::isDigit) || it.isEmpty()) onChange(it) }, label = { Text(label) }, modifier = modifier) }
