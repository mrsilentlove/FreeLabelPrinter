package com.example.freelabelprinter.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class LocalStore(context: Context) {
    private val prefs = context.getSharedPreferences("printer_app_data", Context.MODE_PRIVATE)

    fun saveReceiptTemplate(template: SavedTemplate) = saveTemplate("receipt_templates", template)
    fun saveLabelTemplate(template: SavedTemplate) = saveTemplate("label_templates", template)

    private fun saveTemplate(key: String, template: SavedTemplate) {
        val list = JSONArray(prefs.getString(key, "[]"))
        list.put(JSONObject()
            .put("id", template.id)
            .put("name", template.name)
            .put("type", template.type)
            .put("updatedAt", template.updatedAt)
            .put("dataJson", template.dataJson))
        prefs.edit().putString(key, list.toString()).apply()
    }

    fun addPrintRecord(record: PrintRecord) {
        val list = JSONArray(prefs.getString("print_history", "[]"))
        list.put(JSONObject()
            .put("id", record.id)
            .put("type", record.type)
            .put("title", record.title)
            .put("timestamp", record.timestamp)
            .put("copies", record.copies)
            .put("printer", record.printer)
            .put("dataJson", record.dataJson))
        prefs.edit().putString("print_history", list.toString()).apply()
    }

    fun history(): List<PrintRecord> {
        val list = JSONArray(prefs.getString("print_history", "[]"))
        return (0 until list.length()).map { i ->
            val o = list.getJSONObject(i)
            PrintRecord(
                id = o.optLong("id"),
                type = o.optString("type"),
                title = o.optString("title"),
                timestamp = o.optLong("timestamp"),
                copies = o.optInt("copies", 1),
                printer = o.optString("printer"),
                dataJson = o.optString("dataJson")
            )
        }.reversed()
    }

    fun exportBackupJson(): String = JSONObject()
        .put("backupVersion", 1)
        .put("createdAt", System.currentTimeMillis())
        .put("receiptTemplates", JSONArray(prefs.getString("receipt_templates", "[]")))
        .put("labelTemplates", JSONArray(prefs.getString("label_templates", "[]")))
        .put("printHistory", JSONArray(prefs.getString("print_history", "[]")))
            .put("products", JSONArray(context.getSharedPreferences("printer_products", Context.MODE_PRIVATE).getString("products", "[]")))
            .put("settings", JSONObject(prefs.getString("app_settings", "{}")))
        .toString(2)

    fun restoreBackupJson(json: String) {
        val root = JSONObject(json)
        prefs.edit()
            .putString("receipt_templates", root.optJSONArray("receiptTemplates")?.toString() ?: "[]")
            .putString("label_templates", root.optJSONArray("labelTemplates")?.toString() ?: "[]")
            .putString("print_history", root.optJSONArray("printHistory")?.toString() ?: "[]")
            .putString("app_settings", root.optJSONObject("settings")?.toString() ?: "{}")
            .apply()
        context.getSharedPreferences("printer_products", Context.MODE_PRIVATE).edit()
            .putString("products", root.optJSONArray("products")?.toString() ?: "[]").apply()
    }
}
