package com.example.freelabelprinter.data

data class Product(
    val id: Long = System.currentTimeMillis(),
    val name: String,
    val sku: String = "",
    val barcode: String = "",
    val price: Double = 0.0,
    val description: String = ""
)
