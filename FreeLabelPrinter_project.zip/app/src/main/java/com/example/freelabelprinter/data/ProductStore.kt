package com.example.freelabelprinter.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class ProductStore(context: Context) {
    private val prefs = context.getSharedPreferences("printer_products", Context.MODE_PRIVATE)

    fun all(): List<Product> {
        val a = JSONArray(prefs.getString("products", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Product(
                id = o.optLong("id"),
                name = o.optString("name"),
                sku = o.optString("sku"),
                barcode = o.optString("barcode"),
                price = o.optDouble("price", 0.0),
                description = o.optString("description")
            )
        }
    }

    fun add(p: Product) {
        val a = JSONArray(prefs.getString("products", "[]"))
        a.put(JSONObject()
            .put("id", p.id)
            .put("name", p.name)
            .put("sku", p.sku)
            .put("barcode", p.barcode)
            .put("price", p.price)
            .put("description", p.description))
        prefs.edit().putString("products", a.toString()).apply()
    }

    fun delete(id: Long) {
        val old = all().filter { it.id != id }
        val a = JSONArray()
        old.forEach { p ->
            a.put(JSONObject()
                .put("id", p.id).put("name", p.name).put("sku", p.sku)
                .put("barcode", p.barcode).put("price", p.price)
                .put("description", p.description))
        }
        prefs.edit().putString("products", a.toString()).apply()
    }
}
