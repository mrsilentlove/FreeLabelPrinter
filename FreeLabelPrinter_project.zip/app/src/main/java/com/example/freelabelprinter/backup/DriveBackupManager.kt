package com.example.freelabelprinter.backup

import android.content.Context
import com.example.freelabelprinter.data.LocalStore
import java.io.File

class DriveBackupManager(private val context: Context) {
    private val store = LocalStore(context)

    fun createBackupFile(): File {
        val file = File(context.cacheDir, "printer_backup_${System.currentTimeMillis()}.json")
        file.writeText(store.exportBackupJson())
        return file
    }

    fun restoreFromJson(json: String) {
        store.restoreBackupJson(json)
    }

    /*
     * Google Drive upload/download should be connected here using the user's
     * signed-in Google account. Keep the Drive file id in app preferences so
     * the same backup file can be versioned instead of creating duplicates.
     */
}
