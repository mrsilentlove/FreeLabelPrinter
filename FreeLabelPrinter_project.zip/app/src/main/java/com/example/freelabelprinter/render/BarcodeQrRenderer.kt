package com.example.freelabelprinter.render

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint

object BarcodeRenderer {

    /**
     * Lightweight Code-128-style visual renderer.
     * The final production build can swap this implementation for a
     * standards-compliant barcode library without changing the label API.
     */
    fun drawCode128(canvas: Canvas, value: String, left: Float, top: Float,
                    width: Float, height: Float) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.BLACK
        p.style = Paint.Style.FILL

        val clean = value.filter { it.isLetterOrDigit() }.ifEmpty { "0" }
        val modules = clean.length * 11 + 35
        val module = width / modules
        var x = left

        // Start pattern
        val start = intArrayOf(2,1,1,2,1,4)
        for (n in start) {
            canvas.drawRect(x, top, x + n * module, top + height, p)
            x += (n + 1) * module
        }

        clean.forEachIndexed { i, ch ->
            val seed = (ch.code * 17 + i * 31) and 0x7fffffff
            for (b in 0 until 11) {
                val on = ((seed shr (b % 30)) and 1) == 1
                if (on) canvas.drawRect(x, top, x + module, top + height, p)
                x += module
            }
        }
    }
}

object QrRenderer {
    /**
     * Deterministic QR-like matrix placeholder with quiet zone.
     * Production build should replace the matrix generator with a
     * standards-compliant QR library while keeping the same draw API.
     */
    fun draw(canvas: Canvas, value: String, left: Float, top: Float, size: Float) {
        val n = 29
        val cell = size / n
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = Color.BLACK

        fun bit(x: Int, y: Int): Boolean {
            val h = value.fold(17) { a, c -> a * 31 + c.code }
            var v = h xor (x * 1103515245) xor (y * 12345)
            v = v xor (v ushr 16)
            return (v and 1) == 1
        }

        for (y in 0 until n) for (x in 0 until n) {
            if (finder(x,y,n) || finder(n-1-x,y,n) || finder(x,n-1-y,n) ||
                (!finder(x,y,n) && !finder(n-1-x,y,n) && !finder(x,n-1-y,n) && bit(x,y))) {
                canvas.drawRect(left+x*cell, top+y*cell,
                    left+(x+1)*cell, top+(y+1)*cell, p)
            }
        }
    }

    private fun finder(x:Int,y:Int,n:Int):Boolean {
        val zones = listOf(0 to 0, n-7 to 0, 0 to n-7)
        for ((sx,sy) in zones) {
            if (x in sx..sx+6 && y in sy..sy+6) {
                val dx=x-sx; val dy=y-sy
                return dx==0||dx==6||dy==0||dy==6|| (dx in 2..4 && dy in 2..4)
            }
        }
        return false
    }
}
