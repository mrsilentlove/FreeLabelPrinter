package com.example.freelabelprinter.receipt

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import kotlin.math.roundToInt

data class ReceiptItem(
    val name: String,
    val quantity: Double,
    val price: Double
) {
    val total: Double get() = quantity * price
}

data class ReceiptData(
    val shopName: String = "Punjab Restaurant Pizza & Fast Food",
    val phone: String = "",
    val address: String = "",
    val receiptNo: String = "",
    val dateTime: String = "",
    val items: List<ReceiptItem> = emptyList(),
    val discount: Double = 0.0,
    val footer: String = "Thank you!"
) {
    val subtotal: Double get() = items.sumOf { it.total }
    val grandTotal: Double get() = (subtotal - discount).coerceAtLeast(0.0)
}

class ReceiptBitmapRenderer(
    private val dpi: Int = 203
) {
    private fun mm(mm: Double): Int =
        (mm * dpi / 25.4).roundToInt()

    fun render(data: ReceiptData, paperWidthMm: Double = 80.0): Bitmap {
        val width = mm(paperWidthMm)
        val lineH = mm(5.0)
        val headerH = mm(34.0)
        val itemH = lineH * (data.items.size + 5)
        val footerH = mm(14.0)
        val height = headerH + itemH + footerH

        val bitmap = Bitmap.createBitmap(
            width, height, Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bitmap)
        canvas.drawColor(android.graphics.Color.WHITE)

        val normal = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.BLACK
            textSize = mm(3.1).toFloat()
            typeface = Typeface.DEFAULT
        }
        val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = android.graphics.Color.BLACK
            textSize = mm(4.0).toFloat()
            typeface = Typeface.DEFAULT_BOLD
        }

        var y = mm(5.0).toFloat()

        fun center(text: String, paint: Paint) {
            val x = (width - paint.measureText(text)) / 2f
            canvas.drawText(text, x, y, paint)
            y += lineH
        }

        fun left(text: String, paint: Paint = normal) {
            canvas.drawText(text, mm(3.0).toFloat(), y, paint)
            y += lineH
        }

        center(data.shopName, bold)
        if (data.phone.isNotBlank()) center(data.phone, normal)
        if (data.address.isNotBlank()) center(data.address, normal)

        left("Receipt: ${data.receiptNo}")
        left(data.dateTime)

        canvas.drawLine(
            mm(3.0).toFloat(), y,
            (width-mm(3.0)).toFloat(), y, normal
        )
        y += lineH

        val rightX = width - mm(3.0)
        left("Item                 Qty       Price      Total", bold)

        data.items.forEach { item ->
            val name = if (item.name.length > 16)
                item.name.take(15) + "…" else item.name
            val text = "%-16s %3.0f %9.2f %9.2f".format(
                name, item.quantity, item.price, item.total
            )
            left(text)
        }

        y += lineH / 2
        left("Subtotal:".padEnd(28) + "%.2f".format(data.subtotal), bold)

        if (data.discount > 0) {
            left("Discount:".padEnd(28) + "%.2f".format(data.discount))
        }

        left("TOTAL:".padEnd(28) + "%.2f".format(data.grandTotal), bold)
        y += lineH

        center(data.footer, normal)

        return bitmap
    }
}

// Designer renderer: produces a Star TSP100III-compatible raster receipt.
fun ReceiptRenderer.renderDesign(design: com.example.freelabelprinter.data.ReceiptDesign): android.graphics.Bitmap {
    val width = 576
    val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
    val bmp = android.graphics.Bitmap.createBitmap(width, 1800, android.graphics.Bitmap.Config.ARGB_8888)
    val canvas = android.graphics.Canvas(bmp)
    canvas.drawColor(android.graphics.Color.WHITE)
    paint.color = android.graphics.Color.BLACK
    var y = 40f

    paint.textAlign = android.graphics.Paint.Align.CENTER
    paint.textSize = design.shopNameSize.toFloat()
    paint.isFakeBoldText = true
    canvas.drawText(design.shopName, width / 2f, y, paint)
    paint.isFakeBoldText = false
    paint.textSize = design.bodySize.toFloat()
    y += 32
    if (design.phone.isNotBlank()) { canvas.drawText(design.phone, width / 2f, y, paint); y += 25 }
    if (design.address.isNotBlank()) { canvas.drawText(design.address, width / 2f, y, paint); y += 25 }

    paint.textAlign = android.graphics.Paint.Align.LEFT
    y += 15
    if (design.showDateTime) { canvas.drawText("Date: 28-09-2026  03:00 PM", 18f, y, paint); y += 24 }
    if (design.showReceiptNo) { canvas.drawText("Receipt No: 000001", 18f, y, paint); y += 24 }
    if (design.showItemTable) {
        y += 8
        canvas.drawText("Item", 18f, y, paint); canvas.drawText("Qty", 365f, y, paint); canvas.drawText("Price", 470f, y, paint)
        y += 24
        canvas.drawText("Sample Product", 18f, y, paint); canvas.drawText("1", 370f, y, paint); canvas.drawText("Rs 300", 465f, y, paint)
        y += 28; canvas.drawLine(18f, y, 558f, y, paint)
    }
    if (design.showDiscount) { y += 28; canvas.drawText("Discount: Rs 0", 18f, y, paint) }
    if (design.showTax) { y += 24; canvas.drawText("Tax: Rs 0", 18f, y, paint) }
    y += 30; paint.isFakeBoldText = true; canvas.drawText("TOTAL: Rs 300", 18f, y, paint); paint.isFakeBoldText = false

    if (design.showQr) {
        y += 35; canvas.drawRect(210f, y, 366f, y + 156f, paint); paint.textAlign = android.graphics.Paint.Align.CENTER
        canvas.drawText("QR", width / 2f, y + 90f, paint); paint.textAlign = android.graphics.Paint.Align.LEFT
    }
    if (design.showBarcode) {
        y += 190
        for (i in 0 until 32) if (i % 2 == 0) canvas.drawRect(80f + i * 12f, y, 84f + i * 12f, y + 70f, paint)
        y += 88
    }
    paint.textAlign = android.graphics.Paint.Align.CENTER; paint.textSize = design.footerSize.toFloat()
    canvas.drawText(design.footer, width / 2f, y + 25f, paint)
    return android.graphics.Bitmap.createBitmap(bmp, 0, 0, width, minOf(bmp.height, y.toInt() + 70))
}
