package com.example.freelabelprinter.data

data class PrintRecord(
    val id: Long = System.currentTimeMillis(),
    val type: String = "RECEIPT",
    val title: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val copies: Int = 1,
    val printer: String = "",
    val dataJson: String = ""
)
