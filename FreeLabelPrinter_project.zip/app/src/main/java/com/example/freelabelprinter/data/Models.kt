package com.example.freelabelprinter.data

data class LabelDesign(
    val id: Long,
    val name: String,
    val widthMm: Double,
    val heightMm: Double,
    val gapMm: Double,
    val paperWidthMm: Double,
    val product: String,
    val price: String,
    val barcode: String
)

data class PrintRecord(
    val id: Long,
    val designName: String,
    val itemName: String,
    val quantity: Int,
    val printedAt: Long
)
