# Free Label Printer — TSP100III Bluetooth — v11 Full Feature Scaffold

Included:
- Star TSP100III Bluetooth printing architecture.
- 80mm raster receipt printing.
- Free-size label layout with automatic columns.
- Receipt Designer with preview and configurable sections.
- Real QR and Code 128 generator foundation.
- Print history.
- History Reprint / Share UI.
- Saved receipt and label template storage foundation.
- Product / item database with SKU, barcode, price and description.
- Backup JSON now includes history, templates, products and settings.
- Backup/restore UI foundation.
- App settings model for paper width, auto-cut, copies and default label size.

Planned final integration:
- Wire every print success to history automatically.
- Load/edit/delete templates directly from UI.
- Connect product picker to receipt/label designer.
- Google Sign-In + Google Drive upload/download/versioning.
- PDF/document/image import and print.
- OCR camera/gallery flow.
- Full drag-and-drop receipt designer.
- Production build/test against exact StarIO10/StarXpand SDK.
- Final APK signing and installation test.

This is source code/scaffold, not a verified compiled APK.
