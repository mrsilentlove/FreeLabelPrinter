# FreeLabelPrinter — Codemagic-ready source

Native Android/Kotlin project for the FreeLabelPrinter + SMS Auto Print/TSP100 work.

## Codemagic
- Repository root contains `settings.gradle`, `build.gradle`, `app/`, and `codemagic.yaml`.
- `android-debug` builds an installable debug APK.
- `android-release` builds a release APK. For a signed release, add an Android keystore in Codemagic and configure the signing reference in `codemagic.yaml`.

## SMS
- SMS receiver with selected sender/company rules
- custom transaction and amount aliases
- service charge and optional display
- SMS receive timestamp
- duplicate transaction protection
- company-wise SMS sale totals and transaction counts
- SMS settings screen

## Printer
The SMS bridge uses the existing StarIO10/StarXpand `StarPrinterManager` and its `printAsync(commands)` path for Star Bluetooth printers. Bluetooth permissions must be granted after installing the app.

## Important
This is source code. The APK must be built and tested in CI before being treated as a production release. The exact TSP100/TSP100III hardware behavior still needs a real-printer test after the first successful cloud build.
